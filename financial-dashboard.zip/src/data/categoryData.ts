export const categoryData = [
  { name: "Housing", value: 1200 },
  { name: "Food", value: 500 },
  { name: "Transportation", value: 350 },
  { name: "Entertainment", value: 250 },
  { name: "Healthcare", value: 300 },
  { name: "Shopping", value: 400 },
  { name: "Utilities", value: 200 },
  { name: "Other", value: 150 },
]
