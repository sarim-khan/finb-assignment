export const userData = {
  name: "Sarah Johnson",
  avatar: "https://randomuser.me/api/portraits/women/44.jpg",
  savingsGoal: 2000,
  currentSavings: 1200,
}
